import os
import click
import sys
import integrity_check
import inquirer
from code_signing import program_vendor
from pprint import pprint
import pick

VIRUS_SCANNER_PATH = "virus_scanner.exe"
DANGEROUS_FILES = "dangerous_files.txt"
sys.path.append(os.path.realpath("."))
PICK_INDICATOR = ">"

@click.group()
def commands():
    pass


@click.command()
@click.argument("directory_path", type=click.Path(exists=True, file_okay=False))
def scan_virus(directory_path):
    """ Search for the virus in specific directory """
    os.system(f"{VIRUS_SCANNER_PATH} {directory_path}")
    click.secho("finished scan.", fg="green")
    return


@click.command()
@click.argument("directory_path", type=click.Path(exists=True, file_okay=False))
def save_checksums(directory_path):
    """ Save checksums to all files in directory """
    integrity_check.save_checksums(directory_path)
    click.secho("saved checksums.", fg="green")
    return


@click.command()
def scan_for_changes():
    """ Scan for changes in files with saved checksums. """
    integrity_check.check_files()
    click.secho("scanned changes.", fg="green")
    return


@click.command()
def get_program():
    """ Get program safety. """
    program_options = program_vendor.get_programs_provided()
    chosen_program, _ = pick.pick(program_options, title="PROGRAM PROVIDED:", indicator=PICK_INDICATOR)
    print(f"program chosen is {chosen_program}")


commands.add_command(save_checksums)
commands.add_command(scan_virus)
commands.add_command(scan_for_changes)
commands.add_command(get_program)


def main():
    commands()


if __name__ == "__main__":
    main()
